namespace EmployeeApiCRUD.Models;

public class Skill
{
    public int Id { get; set; }
    public string Name { get; set; } = string.Empty;
}